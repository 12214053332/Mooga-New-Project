<?php
define('FB_APP_ID','179617585752895');
define('FB_APP_SECRET','dd1ba2183d2113ef46041893bec65edc');
define('FB_DEFAULT_ACCESS_TOKEN','8ae5c2d567433b3593b34e38f6ee9375');
define('FB_REDIRECT_URL','http://localhost/moogav2/fblogin/fpLogin.php');